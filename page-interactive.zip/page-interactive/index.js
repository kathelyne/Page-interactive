var bg = document.getElementById("particles-js");

document.addEventListener("keydown", function(event) {
    bg.style.backgroundColor = getRandomColor();
    var key = event.key;
    playMusic(key);
    console.log(event);
});

function getRandomColor() {
    var letters = "0123456789ABCDEF"
    var color = "#";
    for (var i = 0; i < 6; i++) {
        color = color + letters[Math.floor(Math.random() * letters.length)]
    }
    return color;
}

function playMusic(key) {
    switch (key) {
        case "a":
        case "z":
        case "e":
        case "r":
        case "t":
        case "y":
        case "u":
        case "i":
        case "o":
        case "p":
            var audio1 = new Audio("Kick1.wav");
            audio1.play();
            break;
        case "q":
        case "s":
        case "d":
        case "f":
        case "g":
        case "h":
        case "j":
        case "j":
        case "k":
        case "l":
        case "m":

            var audio2 = new Audio("kick2.mp3");
            audio2.play();
            break;
        case "w":
        case "x":
        case "c":
        case "v":
        case "b":
        case "n":

            var audio3 = new Audio("kick.mp3");
            audio3.play();
            break;
    };
}